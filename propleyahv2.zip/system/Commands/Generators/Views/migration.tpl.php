<@php

namespace {namespace};

use CodeIgniter\Database\Migration;

class {class} extends Migration
{
	public function up()
	{
		//
	}

	public function down()
	{
		//
	}
}
