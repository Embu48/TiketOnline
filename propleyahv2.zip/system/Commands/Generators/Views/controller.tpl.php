<@php

namespace {namespace};

{useStatement}

class {class} {extends}
{
	public function index()
	{
		//
	}
	{restfulMethods}
}
