<@php

namespace {namespace};

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class {class} implements FilterInterface
{
	/**
	 * {@inheritdoc}
	 */
	public function before(RequestInterface $request, $arguments = null)
	{
		//
	}

	/**
	 * {@inheritdoc}
	 */
	public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
	{
		//
	}
}
