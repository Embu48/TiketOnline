<?php 
namespace Tests\Support\Config\Filters;

$filters->aliases['test-customfilter'] = \Tests\Support\Filters\Customfilter::class;
